﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test_tues_2
{
    internal class User
    {
        public string username { get; set; } = "abcd";
        public string password { get; set; } = "abcd";

        public void check1 (string Un, string psswd)
        {
            if(this.username == Un)
            {
                if(this.password == psswd)
                {
                    Console.WriteLine("You have logged in Successfully!!!!!!");
                }
                else
                {
                    Console.WriteLine("Wrong Password");
                }
            }
            else
            {
                Console.WriteLine("Wrong UserName: !!");
            }
        }
    }
}
