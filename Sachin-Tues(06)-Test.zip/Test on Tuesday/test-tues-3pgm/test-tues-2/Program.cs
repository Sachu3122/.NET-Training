﻿using System;

namespace test_tues_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Test User Credentials : ");
            Console.Write("Please enter username : ");
            string Uname = Console.ReadLine();
            Console.Write("Please enter your password : ");
            string psswd =  Console.ReadLine();

            User user = new User();
            user.check1(Uname, psswd);
        }
    }
}
