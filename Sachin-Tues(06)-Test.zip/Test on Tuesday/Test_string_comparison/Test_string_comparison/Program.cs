﻿using System;
using System.Buffers.Text;
//using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
//using System.Net.Sockets;
//using System.Reflection.Emit;
using System.Threading;

public class String_Check
{
    public static void Main()
    {
        String[] cultureNames = { "en-US", "en-US" };
        String[] str1 = { "case",  "encyclopedia",
                            "encyclopedia"};
        String[] str2 = { "Case", "encyclopedia",
                            "encyclopedia"};
        StringComparison[] strcom = (StringComparison[])Enum.GetValues(typeof(StringComparison));

        foreach (var cultureName in cultureNames)
        {
            Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(cultureName);
            Console.WriteLine("Current Culture: {0}", CultureInfo.CurrentCulture.Name);
            for (int ctr = 0; ctr <= str1.GetUpperBound(0); ctr++)
            {
                foreach (var val in strcom)
                    Console.WriteLine("   {0} = {1} ({2}): {3}", str1[ctr],
                                      str2[ctr], val,
                                      String.Equals(str1[ctr], str2[ctr], val));

                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }
}
