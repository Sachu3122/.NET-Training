﻿using System;
using System.Text;
using Test_Roman;

namespace exercises
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("'I','V', 'X', 'L', 'C', 'D', 'M': ");
            Console.Write("Enter a String using above Chars : ");
            string s = Console.ReadLine();
            Roman roman1 = new Roman();
            Console.WriteLine( roman1.roman_to_int(s));
        }
    }
}
