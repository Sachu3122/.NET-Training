﻿using System;

namespace Test_Permutation
{
    internal class Program
    {
        static void permutation(int[] a,int val, int len)
        {
            if(val == len)
            {
                foreach(var item in a)
                {
                    Console.Write(item);
                }
            }
            else
            {
                for(int i= 0; i < len; i++)
                {
                    int temp = a[i];
                    a[i] = a[val];
                    a[val] = temp;
                    permutation(a, val+1, len);

                    temp = a[i];
                    a[i]=a[val];
                    a[val]=temp;
                }
            }
        }
        static void Main(string[] args)
        {
            int[] arr = { 1, 2, 3 };
            Console.WriteLine("Hello World!");
            permutation(arr,0,arr.Length);
        }
    }
}
