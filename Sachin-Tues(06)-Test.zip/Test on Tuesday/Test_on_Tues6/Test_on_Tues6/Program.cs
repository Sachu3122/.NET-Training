﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;



namespace Test_on_Tues6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Write a program in C# Sharp to find the sum of all elements of the array.  

            Test Data:

            Input the number of elements to be stored in the array :3

            Input 3 elements in the array : 

            element - 0 : 2

            element - 1 : 5

            element - 2 : 8

            Expected Output : 

            Sum of all elements stored in the array is : 15*/

            int[] a = { 1, 2, 3 };
            int sum = 0;
            foreach (int i in a)
            {
                sum += i;
                //Console.WriteLine(i);
            }
            Console.WriteLine("Sum of the elements in array : " + sum);

            /*
             * Write a program in C# SharpCo 

            Test Data : 

            Input the number of elements to be stored in the array :3 

            Input 3 elements in the array : 

            element - 0 : 1 

            element - 1 : 5 

            element - 2 : 1 

            Expected Output : 

            The unique elements found in the array are : 

            5*/ 

            int[] b = {1, 2, 3, 3, 4, 2, 5};
            
            for(int i = 0; i < b.Length; i++)
            {
                int count = 0;
                for(int j = i+1; j<b.Length; j++)
                {
                    if(a[i] == b[j])
                    {
                        count++;    
                    }
                }
                if (count < 1)
                {
                   Console.WriteLine(a[i]);
                }
            }


            /*

Write a program in C# Sharp for a 2D array of size 3x3 and print the matrix.  
Test Data : Input elements in the matrix : 
element - [0],[0] : 1 
element - [0],[1] : 2 
element - [0],[2] : 3 
element - [1],[0] : 4 
element - [1],[1] : 5 
element - [1],[2] : 6 
element - [2],[0] : 7 
element - [2],[1] : 8 
element - [2],[2] : 9 
Expected Output : 
The matrix is : 
1 2 3 
4 5 6 
7 8 9 
Write a program in C# Sharp to ch
 */
            int[,] arr = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
            int count = 1;
            foreach (int i in arr)
            {  
                Console.Write(i+" ");
                if (count % 3 == 0)
                {
                    Console.WriteLine();
                    count = 1;
                }
                else { count++; }
            }

        }
    }
}
